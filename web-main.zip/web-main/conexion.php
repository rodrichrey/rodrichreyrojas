<?php
$mysqli=new mysqli("localhost","root","","bd_tienda");
?>